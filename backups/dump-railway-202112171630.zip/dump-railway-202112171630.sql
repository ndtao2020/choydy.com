--
-- PostgreSQL database dump
--

-- Dumped from database version 13.2
-- Dumped by pg_dump version 13.3

-- Started on 2021-12-17 16:30:14

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- TOC entry 5 (class 2615 OID 2200)
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- TOC entry 3466 (class 0 OID 0)
-- Dependencies: 5
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- TOC entry 247 (class 1259 OID 17486)
-- Name: authority; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.authority (
    id character varying(255) NOT NULL,
    name character varying(255) NOT NULL
);


ALTER TABLE public.authority OWNER TO postgres;

--
-- TOC entry 259 (class 1259 OID 18796)
-- Name: catalog; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.catalog (
    id bigint NOT NULL,
    icon character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    priority integer NOT NULL,
    created bigint NOT NULL
);


ALTER TABLE public.catalog OWNER TO postgres;

--
-- TOC entry 257 (class 1259 OID 18758)
-- Name: comment; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.comment (
    id uuid NOT NULL,
    content text NOT NULL,
    likes bigint,
    parent_id uuid,
    post_id uuid NOT NULL,
    user_id uuid NOT NULL,
    created bigint NOT NULL
);


ALTER TABLE public.comment OWNER TO postgres;

--
-- TOC entry 248 (class 1259 OID 17507)
-- Name: country; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.country (
    iso character varying(2) NOT NULL,
    display_name character varying(255) NOT NULL,
    iso3 character varying(3) NOT NULL,
    name character varying(255) NOT NULL,
    num_code integer NOT NULL,
    phone_code integer NOT NULL
);


ALTER TABLE public.country OWNER TO postgres;

--
-- TOC entry 249 (class 1259 OID 17519)
-- Name: hibernate_sequence; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.hibernate_sequence
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.hibernate_sequence OWNER TO postgres;

--
-- TOC entry 250 (class 1259 OID 17527)
-- Name: language; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.language (
    code character varying(2) NOT NULL,
    name character varying(255) NOT NULL,
    native_name character varying(255) NOT NULL,
    code3 character varying(3) NOT NULL,
    nativename character varying(255)
);


ALTER TABLE public.language OWNER TO postgres;

--
-- TOC entry 263 (class 1259 OID 18913)
-- Name: liketype; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.liketype (
    id character varying(255) NOT NULL,
    name character varying(255) NOT NULL
);


ALTER TABLE public.liketype OWNER TO postgres;

--
-- TOC entry 258 (class 1259 OID 18781)
-- Name: media; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.media (
    id uuid NOT NULL,
    link text NOT NULL,
    type character varying(255) NOT NULL,
    post_id uuid NOT NULL
);


ALTER TABLE public.media OWNER TO postgres;

--
-- TOC entry 251 (class 1259 OID 17686)
-- Name: oauth2client; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.oauth2client (
    id uuid NOT NULL,
    access_token_validity integer NOT NULL,
    additional_information character varying(255),
    approve boolean NOT NULL,
    grant_types character varying(255) NOT NULL,
    redirect character varying(255),
    refresh_token_validity integer NOT NULL,
    resources character varying(255),
    scopes character varying(255) NOT NULL,
    secret character varying(255) NOT NULL,
    domain character varying(255) NOT NULL
);


ALTER TABLE public.oauth2client OWNER TO postgres;

--
-- TOC entry 256 (class 1259 OID 18707)
-- Name: post; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.post (
    id uuid NOT NULL,
    comments bigint,
    content text,
    count bigint,
    likes bigint,
    shares bigint,
    title character varying(255) NOT NULL,
    user_id uuid NOT NULL,
    catalog_id bigint NOT NULL,
    disable boolean NOT NULL,
    created bigint NOT NULL
);


ALTER TABLE public.post OWNER TO postgres;

--
-- TOC entry 264 (class 1259 OID 18921)
-- Name: postlike; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.postlike (
    created timestamp without time zone NOT NULL,
    user_id uuid NOT NULL,
    post_id uuid NOT NULL,
    liketype_id character varying(255) NOT NULL
);


ALTER TABLE public.postlike OWNER TO postgres;

--
-- TOC entry 260 (class 1259 OID 18804)
-- Name: posttag; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.posttag (
    tag_id character varying(255) NOT NULL,
    post_id uuid NOT NULL
);


ALTER TABLE public.posttag OWNER TO postgres;

--
-- TOC entry 253 (class 1259 OID 18567)
-- Name: socialnetwork; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.socialnetwork (
    id integer NOT NULL,
    name character varying(150) NOT NULL,
    clientid character varying(255),
    clientsecret character varying(255)
);


ALTER TABLE public.socialnetwork OWNER TO postgres;

--
-- TOC entry 261 (class 1259 OID 18809)
-- Name: tag; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tag (
    id character varying(255) NOT NULL
);


ALTER TABLE public.tag OWNER TO postgres;

--
-- TOC entry 252 (class 1259 OID 17749)
-- Name: user_sys; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_sys (
    id uuid NOT NULL,
    created_by character varying(255),
    created_date timestamp without time zone,
    last_modified_by character varying(255),
    last_modified_date timestamp without time zone,
    avatar character varying(255),
    enabled boolean NOT NULL,
    name character varying(255) NOT NULL,
    password character varying(100) NOT NULL,
    username character varying(255) NOT NULL,
    email character varying(255) NOT NULL,
    active boolean NOT NULL,
    timezone character varying(255) NOT NULL
);


ALTER TABLE public.user_sys OWNER TO postgres;

--
-- TOC entry 262 (class 1259 OID 18832)
-- Name: userauthority; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.userauthority (
    id uuid NOT NULL,
    authority_id character varying(255) NOT NULL,
    user_id uuid NOT NULL
);


ALTER TABLE public.userauthority OWNER TO postgres;

--
-- TOC entry 254 (class 1259 OID 18580)
-- Name: userdetail; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.userdetail (
    id uuid NOT NULL,
    about text,
    address text,
    birthday date,
    gender character varying(255),
    phonenumber character varying(30),
    postalcode character varying(30),
    country_iso character varying(2) NOT NULL,
    user_id uuid NOT NULL
);


ALTER TABLE public.userdetail OWNER TO postgres;

--
-- TOC entry 255 (class 1259 OID 18588)
-- Name: usersocialnetwork; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.usersocialnetwork (
    id uuid NOT NULL,
    avatar character varying(255),
    email character varying(255) NOT NULL,
    phonenumber character varying(255),
    uid character varying(255) NOT NULL,
    social_network_id integer NOT NULL,
    user_id uuid NOT NULL
);


ALTER TABLE public.usersocialnetwork OWNER TO postgres;

--
-- TOC entry 3443 (class 0 OID 17486)
-- Dependencies: 247
-- Data for Name: authority; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.authority VALUES ('ADMIN', 'Quản trị viên');
INSERT INTO public.authority VALUES ('USER', 'Người dùng');
INSERT INTO public.authority VALUES ('EDITOR', 'Biên tập');


--
-- TOC entry 3455 (class 0 OID 18796)
-- Dependencies: 259
-- Data for Name: catalog; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.catalog VALUES (1, '1', 'trending', 0, 1639732998962);
INSERT INTO public.catalog VALUES (2, '1', 'Tiến Bịp', 0, 1639732998962);
INSERT INTO public.catalog VALUES (3, '1', 'Bóng Đá', 0, 1639732998962);
INSERT INTO public.catalog VALUES (4, '1', 'Chị Ong Nâu', 0, 1639732998962);
INSERT INTO public.catalog VALUES (5, '1', 'Bà Phương Hằng', 0, 1639732998962);
INSERT INTO public.catalog VALUES (6, '1', 'Chim Cánh Cụt', 0, 1639732998962);
INSERT INTO public.catalog VALUES (7, '1', 'Drak Meme', 0, 1639732998962);
INSERT INTO public.catalog VALUES (8, '1', 'Xin Link', 0, 1639732998962);
INSERT INTO public.catalog VALUES (9, '1', 'Huấn Hoa Hồng', 0, 1639732998962);
INSERT INTO public.catalog VALUES (10, '1', 'Meme Cheems', 0, 1639732998962);
INSERT INTO public.catalog VALUES (11, '1', 'Meme Gấu Trúc', 0, 1639732998962);
INSERT INTO public.catalog VALUES (12, '1', 'Meme Gấu Chó', 0, 1639732998962);
INSERT INTO public.catalog VALUES (13, '1', 'Meme Chó', 0, 1639732998962);
INSERT INTO public.catalog VALUES (14, '1', 'Meme Mèo', 0, 1639732998962);


--
-- TOC entry 3453 (class 0 OID 18758)
-- Dependencies: 257
-- Data for Name: comment; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- TOC entry 3444 (class 0 OID 17507)
-- Dependencies: 248
-- Data for Name: country; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.country VALUES ('CX', 'Christmas Island', 'CXR', 'CHRISTMAS ISLAND', 162, 61);
INSERT INTO public.country VALUES ('CC', 'Cocos (Keeling) Islands', 'CCK', 'COCOS (KEELING) ISLANDS', 166, 672);
INSERT INTO public.country VALUES ('PS', 'Palestine, State of', 'PSE', 'PALESTINIAN TERRITORY, OCCUPIED', 275, 970);
INSERT INTO public.country VALUES ('IO', 'British Indian Ocean Territory', 'IOT', 'BRITISH INDIAN OCEAN TERRITORY', 86, 246);
INSERT INTO public.country VALUES ('AF', 'Afghanistan', 'AFG', 'AFGHANISTAN', 4, 93);
INSERT INTO public.country VALUES ('AL', 'Albania', 'ALB', 'ALBANIA', 8, 355);
INSERT INTO public.country VALUES ('DZ', 'Algeria', 'DZA', 'ALGERIA', 12, 213);
INSERT INTO public.country VALUES ('AS', 'American Samoa', 'ASM', 'AMERICAN SAMOA', 16, 1684);
INSERT INTO public.country VALUES ('AD', 'Andorra', 'AND', 'ANDORRA', 20, 376);
INSERT INTO public.country VALUES ('AO', 'Angola', 'AGO', 'ANGOLA', 24, 244);
INSERT INTO public.country VALUES ('AI', 'Anguilla', 'AIA', 'ANGUILLA', 660, 1264);
INSERT INTO public.country VALUES ('AG', 'Antigua and Barbuda', 'ATG', 'ANTIGUA AND BARBUDA', 28, 1268);
INSERT INTO public.country VALUES ('AR', 'Argentina', 'ARG', 'ARGENTINA', 32, 54);
INSERT INTO public.country VALUES ('AM', 'Armenia', 'ARM', 'ARMENIA', 51, 374);
INSERT INTO public.country VALUES ('AW', 'Aruba', 'ABW', 'ARUBA', 533, 297);
INSERT INTO public.country VALUES ('AU', 'Australia', 'AUS', 'AUSTRALIA', 36, 61);
INSERT INTO public.country VALUES ('AT', 'Austria', 'AUT', 'AUSTRIA', 40, 43);
INSERT INTO public.country VALUES ('AZ', 'Azerbaijan', 'AZE', 'AZERBAIJAN', 31, 994);
INSERT INTO public.country VALUES ('BS', 'Bahamas', 'BHS', 'BAHAMAS', 44, 1242);
INSERT INTO public.country VALUES ('BH', 'Bahrain', 'BHR', 'BAHRAIN', 48, 973);
INSERT INTO public.country VALUES ('BD', 'Bangladesh', 'BGD', 'BANGLADESH', 50, 880);
INSERT INTO public.country VALUES ('BB', 'Barbados', 'BRB', 'BARBADOS', 52, 1246);
INSERT INTO public.country VALUES ('BY', 'Belarus', 'BLR', 'BELARUS', 112, 375);
INSERT INTO public.country VALUES ('BE', 'Belgium', 'BEL', 'BELGIUM', 56, 32);
INSERT INTO public.country VALUES ('BZ', 'Belize', 'BLZ', 'BELIZE', 84, 501);
INSERT INTO public.country VALUES ('BJ', 'Benin', 'BEN', 'BENIN', 204, 229);
INSERT INTO public.country VALUES ('BM', 'Bermuda', 'BMU', 'BERMUDA', 60, 1441);
INSERT INTO public.country VALUES ('BT', 'Bhutan', 'BTN', 'BHUTAN', 64, 975);
INSERT INTO public.country VALUES ('BO', 'Bolivia', 'BOL', 'BOLIVIA', 68, 591);
INSERT INTO public.country VALUES ('BA', 'Bosnia and Herzegovina', 'BIH', 'BOSNIA AND HERZEGOVINA', 70, 387);
INSERT INTO public.country VALUES ('BW', 'Botswana', 'BWA', 'BOTSWANA', 72, 267);
INSERT INTO public.country VALUES ('BR', 'Brazil', 'BRA', 'BRAZIL', 76, 55);
INSERT INTO public.country VALUES ('BN', 'Brunei Darussalam', 'BRN', 'BRUNEI DARUSSALAM', 96, 673);
INSERT INTO public.country VALUES ('BG', 'Bulgaria', 'BGR', 'BULGARIA', 100, 359);
INSERT INTO public.country VALUES ('BF', 'Burkina Faso', 'BFA', 'BURKINA FASO', 854, 226);
INSERT INTO public.country VALUES ('BI', 'Burundi', 'BDI', 'BURUNDI', 108, 257);
INSERT INTO public.country VALUES ('KH', 'Cambodia', 'KHM', 'CAMBODIA', 116, 855);
INSERT INTO public.country VALUES ('CM', 'Cameroon', 'CMR', 'CAMEROON', 120, 237);
INSERT INTO public.country VALUES ('CA', 'Canada', 'CAN', 'CANADA', 124, 1);
INSERT INTO public.country VALUES ('CV', 'Cape Verde', 'CPV', 'CAPE VERDE', 132, 238);
INSERT INTO public.country VALUES ('KY', 'Cayman Islands', 'CYM', 'CAYMAN ISLANDS', 136, 1345);
INSERT INTO public.country VALUES ('CF', 'Central African Republic', 'CAF', 'CENTRAL AFRICAN REPUBLIC', 140, 236);
INSERT INTO public.country VALUES ('TD', 'Chad', 'TCD', 'CHAD', 148, 235);
INSERT INTO public.country VALUES ('CL', 'Chile', 'CHL', 'CHILE', 152, 56);
INSERT INTO public.country VALUES ('CN', 'China', 'CHN', 'CHINA', 156, 86);
INSERT INTO public.country VALUES ('CO', 'Colombia', 'COL', 'COLOMBIA', 170, 57);
INSERT INTO public.country VALUES ('KM', 'Comoros', 'COM', 'COMOROS', 174, 269);
INSERT INTO public.country VALUES ('CG', 'Congo', 'COG', 'CONGO', 178, 242);
INSERT INTO public.country VALUES ('CD', 'Congo, the Democratic Republic of the', 'COD', 'CONGO, THE DEMOCRATIC REPUBLIC OF THE', 180, 242);
INSERT INTO public.country VALUES ('CK', 'Cook Islands', 'COK', 'COOK ISLANDS', 184, 682);
INSERT INTO public.country VALUES ('CR', 'Costa Rica', 'CRI', 'COSTA RICA', 188, 506);
INSERT INTO public.country VALUES ('CI', 'Cote D''Ivoire', 'CIV', 'COTE D''IVOIRE', 384, 225);
INSERT INTO public.country VALUES ('HR', 'Croatia', 'HRV', 'CROATIA', 191, 385);
INSERT INTO public.country VALUES ('CU', 'Cuba', 'CUB', 'CUBA', 192, 53);
INSERT INTO public.country VALUES ('CY', 'Cyprus', 'CYP', 'CYPRUS', 196, 357);
INSERT INTO public.country VALUES ('CZ', 'Czech Republic', 'CZE', 'CZECH REPUBLIC', 203, 420);
INSERT INTO public.country VALUES ('DK', 'Denmark', 'DNK', 'DENMARK', 208, 45);
INSERT INTO public.country VALUES ('DJ', 'Djibouti', 'DJI', 'DJIBOUTI', 262, 253);
INSERT INTO public.country VALUES ('DM', 'Dominica', 'DMA', 'DOMINICA', 212, 1767);
INSERT INTO public.country VALUES ('DO', 'Dominican Republic', 'DOM', 'DOMINICAN REPUBLIC', 214, 1809);
INSERT INTO public.country VALUES ('EC', 'Ecuador', 'ECU', 'ECUADOR', 218, 593);
INSERT INTO public.country VALUES ('EG', 'Egypt', 'EGY', 'EGYPT', 818, 20);
INSERT INTO public.country VALUES ('SV', 'El Salvador', 'SLV', 'EL SALVADOR', 222, 503);
INSERT INTO public.country VALUES ('GQ', 'Equatorial Guinea', 'GNQ', 'EQUATORIAL GUINEA', 226, 240);
INSERT INTO public.country VALUES ('ER', 'Eritrea', 'ERI', 'ERITREA', 232, 291);
INSERT INTO public.country VALUES ('EE', 'Estonia', 'EST', 'ESTONIA', 233, 372);
INSERT INTO public.country VALUES ('ET', 'Ethiopia', 'ETH', 'ETHIOPIA', 231, 251);
INSERT INTO public.country VALUES ('FK', 'Falkland Islands (Malvinas)', 'FLK', 'FALKLAND ISLANDS (MALVINAS)', 238, 500);
INSERT INTO public.country VALUES ('FO', 'Faroe Islands', 'FRO', 'FAROE ISLANDS', 234, 298);
INSERT INTO public.country VALUES ('FJ', 'Fiji', 'FJI', 'FIJI', 242, 679);
INSERT INTO public.country VALUES ('FI', 'Finland', 'FIN', 'FINLAND', 246, 358);
INSERT INTO public.country VALUES ('FR', 'France', 'FRA', 'FRANCE', 250, 33);
INSERT INTO public.country VALUES ('GF', 'French Guiana', 'GUF', 'FRENCH GUIANA', 254, 594);
INSERT INTO public.country VALUES ('PF', 'French Polynesia', 'PYF', 'FRENCH POLYNESIA', 258, 689);
INSERT INTO public.country VALUES ('GA', 'Gabon', 'GAB', 'GABON', 266, 241);
INSERT INTO public.country VALUES ('GM', 'Gambia', 'GMB', 'GAMBIA', 270, 220);
INSERT INTO public.country VALUES ('GE', 'Georgia', 'GEO', 'GEORGIA', 268, 995);
INSERT INTO public.country VALUES ('DE', 'Germany', 'DEU', 'GERMANY', 276, 49);
INSERT INTO public.country VALUES ('GH', 'Ghana', 'GHA', 'GHANA', 288, 233);
INSERT INTO public.country VALUES ('GI', 'Gibraltar', 'GIB', 'GIBRALTAR', 292, 350);
INSERT INTO public.country VALUES ('GR', 'Greece', 'GRC', 'GREECE', 300, 30);
INSERT INTO public.country VALUES ('GL', 'Greenland', 'GRL', 'GREENLAND', 304, 299);
INSERT INTO public.country VALUES ('GD', 'Grenada', 'GRD', 'GRENADA', 308, 1473);
INSERT INTO public.country VALUES ('GP', 'Guadeloupe', 'GLP', 'GUADELOUPE', 312, 590);
INSERT INTO public.country VALUES ('GU', 'Guam', 'GUM', 'GUAM', 316, 1671);
INSERT INTO public.country VALUES ('GT', 'Guatemala', 'GTM', 'GUATEMALA', 320, 502);
INSERT INTO public.country VALUES ('GN', 'Guinea', 'GIN', 'GUINEA', 324, 224);
INSERT INTO public.country VALUES ('GW', 'Guinea-Bissau', 'GNB', 'GUINEA-BISSAU', 624, 245);
INSERT INTO public.country VALUES ('GY', 'Guyana', 'GUY', 'GUYANA', 328, 592);
INSERT INTO public.country VALUES ('HT', 'Haiti', 'HTI', 'HAITI', 332, 509);
INSERT INTO public.country VALUES ('VA', 'Holy See (Vatican City State)', 'VAT', 'HOLY SEE (VATICAN CITY STATE)', 336, 39);
INSERT INTO public.country VALUES ('HN', 'Honduras', 'HND', 'HONDURAS', 340, 504);
INSERT INTO public.country VALUES ('HK', 'Hong Kong', 'HKG', 'HONG KONG', 344, 852);
INSERT INTO public.country VALUES ('HU', 'Hungary', 'HUN', 'HUNGARY', 348, 36);
INSERT INTO public.country VALUES ('IS', 'Iceland', 'ISL', 'ICELAND', 352, 354);
INSERT INTO public.country VALUES ('IN', 'India', 'IND', 'INDIA', 356, 91);
INSERT INTO public.country VALUES ('ID', 'Indonesia', 'IDN', 'INDONESIA', 360, 62);
INSERT INTO public.country VALUES ('IR', 'Iran, Islamic Republic of', 'IRN', 'IRAN, ISLAMIC REPUBLIC OF', 364, 98);
INSERT INTO public.country VALUES ('IQ', 'Iraq', 'IRQ', 'IRAQ', 368, 964);
INSERT INTO public.country VALUES ('IE', 'Ireland', 'IRL', 'IRELAND', 372, 353);
INSERT INTO public.country VALUES ('IL', 'Israel', 'ISR', 'ISRAEL', 376, 972);
INSERT INTO public.country VALUES ('IT', 'Italy', 'ITA', 'ITALY', 380, 39);
INSERT INTO public.country VALUES ('JM', 'Jamaica', 'JAM', 'JAMAICA', 388, 1876);
INSERT INTO public.country VALUES ('JP', 'Japan', 'JPN', 'JAPAN', 392, 81);
INSERT INTO public.country VALUES ('JO', 'Jordan', 'JOR', 'JORDAN', 400, 962);
INSERT INTO public.country VALUES ('KZ', 'Kazakhstan', 'KAZ', 'KAZAKHSTAN', 398, 7);
INSERT INTO public.country VALUES ('KE', 'Kenya', 'KEN', 'KENYA', 404, 254);
INSERT INTO public.country VALUES ('KI', 'Kiribati', 'KIR', 'KIRIBATI', 296, 686);
INSERT INTO public.country VALUES ('KP', 'Korea, Democratic People''s Republic of', 'PRK', 'KOREA, DEMOCRATIC PEOPLE''S REPUBLIC OF', 408, 850);
INSERT INTO public.country VALUES ('KR', 'Korea, Republic of', 'KOR', 'KOREA, REPUBLIC OF', 410, 82);
INSERT INTO public.country VALUES ('KW', 'Kuwait', 'KWT', 'KUWAIT', 414, 965);
INSERT INTO public.country VALUES ('KG', 'Kyrgyzstan', 'KGZ', 'KYRGYZSTAN', 417, 996);
INSERT INTO public.country VALUES ('ME', 'Montenegro', 'MNE', 'MONTENEGRO', 499, 382);
INSERT INTO public.country VALUES ('BV', 'Bouvet Island', 'BVT', 'BOUVET ISLAND', 74, 55);
INSERT INTO public.country VALUES ('HM', 'Heard Island and Mcdonald Islands', 'HMD', 'HEARD ISLAND AND MCDONALD ISLANDS', 334, 672);
INSERT INTO public.country VALUES ('LA', 'Lao People''s Democratic Republic', 'LAO', 'LAO PEOPLE''S DEMOCRATIC REPUBLIC', 418, 856);
INSERT INTO public.country VALUES ('LV', 'Latvia', 'LVA', 'LATVIA', 428, 371);
INSERT INTO public.country VALUES ('LB', 'Lebanon', 'LBN', 'LEBANON', 422, 961);
INSERT INTO public.country VALUES ('LS', 'Lesotho', 'LSO', 'LESOTHO', 426, 266);
INSERT INTO public.country VALUES ('LR', 'Liberia', 'LBR', 'LIBERIA', 430, 231);
INSERT INTO public.country VALUES ('LY', 'Libyan Arab Jamahiriya', 'LBY', 'LIBYAN ARAB JAMAHIRIYA', 434, 218);
INSERT INTO public.country VALUES ('LI', 'Liechtenstein', 'LIE', 'LIECHTENSTEIN', 438, 423);
INSERT INTO public.country VALUES ('LT', 'Lithuania', 'LTU', 'LITHUANIA', 440, 370);
INSERT INTO public.country VALUES ('LU', 'Luxembourg', 'LUX', 'LUXEMBOURG', 442, 352);
INSERT INTO public.country VALUES ('MO', 'Macao', 'MAC', 'MACAO', 446, 853);
INSERT INTO public.country VALUES ('MK', 'Macedonia, the Former Yugoslav Republic of', 'MKD', 'MACEDONIA, THE FORMER YUGOSLAV REPUBLIC OF', 807, 389);
INSERT INTO public.country VALUES ('MG', 'Madagascar', 'MDG', 'MADAGASCAR', 450, 261);
INSERT INTO public.country VALUES ('MW', 'Malawi', 'MWI', 'MALAWI', 454, 265);
INSERT INTO public.country VALUES ('MY', 'Malaysia', 'MYS', 'MALAYSIA', 458, 60);
INSERT INTO public.country VALUES ('MV', 'Maldives', 'MDV', 'MALDIVES', 462, 960);
INSERT INTO public.country VALUES ('ML', 'Mali', 'MLI', 'MALI', 466, 223);
INSERT INTO public.country VALUES ('MT', 'Malta', 'MLT', 'MALTA', 470, 356);
INSERT INTO public.country VALUES ('MH', 'Marshall Islands', 'MHL', 'MARSHALL ISLANDS', 584, 692);
INSERT INTO public.country VALUES ('MQ', 'Martinique', 'MTQ', 'MARTINIQUE', 474, 596);
INSERT INTO public.country VALUES ('MR', 'Mauritania', 'MRT', 'MAURITANIA', 478, 222);
INSERT INTO public.country VALUES ('MU', 'Mauritius', 'MUS', 'MAURITIUS', 480, 230);
INSERT INTO public.country VALUES ('MX', 'Mexico', 'MEX', 'MEXICO', 484, 52);
INSERT INTO public.country VALUES ('FM', 'Micronesia, Federated States of', 'FSM', 'MICRONESIA, FEDERATED STATES OF', 583, 691);
INSERT INTO public.country VALUES ('MD', 'Moldova, Republic of', 'MDA', 'MOLDOVA, REPUBLIC OF', 498, 373);
INSERT INTO public.country VALUES ('MC', 'Monaco', 'MCO', 'MONACO', 492, 377);
INSERT INTO public.country VALUES ('MN', 'Mongolia', 'MNG', 'MONGOLIA', 496, 976);
INSERT INTO public.country VALUES ('MS', 'Montserrat', 'MSR', 'MONTSERRAT', 500, 1664);
INSERT INTO public.country VALUES ('MA', 'Morocco', 'MAR', 'MOROCCO', 504, 212);
INSERT INTO public.country VALUES ('MZ', 'Mozambique', 'MOZ', 'MOZAMBIQUE', 508, 258);
INSERT INTO public.country VALUES ('MM', 'Myanmar', 'MMR', 'MYANMAR', 104, 95);
INSERT INTO public.country VALUES ('NA', 'Namibia', 'NAM', 'NAMIBIA', 516, 264);
INSERT INTO public.country VALUES ('NR', 'Nauru', 'NRU', 'NAURU', 520, 674);
INSERT INTO public.country VALUES ('NP', 'Nepal', 'NPL', 'NEPAL', 524, 977);
INSERT INTO public.country VALUES ('NL', 'Netherlands', 'NLD', 'NETHERLANDS', 528, 31);
INSERT INTO public.country VALUES ('NC', 'New Caledonia', 'NCL', 'NEW CALEDONIA', 540, 687);
INSERT INTO public.country VALUES ('NZ', 'New Zealand', 'NZL', 'NEW ZEALAND', 554, 64);
INSERT INTO public.country VALUES ('NI', 'Nicaragua', 'NIC', 'NICARAGUA', 558, 505);
INSERT INTO public.country VALUES ('NE', 'Niger', 'NER', 'NIGER', 562, 227);
INSERT INTO public.country VALUES ('NG', 'Nigeria', 'NGA', 'NIGERIA', 566, 234);
INSERT INTO public.country VALUES ('NU', 'Niue', 'NIU', 'NIUE', 570, 683);
INSERT INTO public.country VALUES ('NF', 'Norfolk Island', 'NFK', 'NORFOLK ISLAND', 574, 672);
INSERT INTO public.country VALUES ('MP', 'Northern Mariana Islands', 'MNP', 'NORTHERN MARIANA ISLANDS', 580, 1670);
INSERT INTO public.country VALUES ('NO', 'Norway', 'NOR', 'NORWAY', 578, 47);
INSERT INTO public.country VALUES ('OM', 'Oman', 'OMN', 'OMAN', 512, 968);
INSERT INTO public.country VALUES ('PK', 'Pakistan', 'PAK', 'PAKISTAN', 586, 92);
INSERT INTO public.country VALUES ('PW', 'Palau', 'PLW', 'PALAU', 585, 680);
INSERT INTO public.country VALUES ('PA', 'Panama', 'PAN', 'PANAMA', 591, 507);
INSERT INTO public.country VALUES ('PG', 'Papua New Guinea', 'PNG', 'PAPUA NEW GUINEA', 598, 675);
INSERT INTO public.country VALUES ('PY', 'Paraguay', 'PRY', 'PARAGUAY', 600, 595);
INSERT INTO public.country VALUES ('PE', 'Peru', 'PER', 'PERU', 604, 51);
INSERT INTO public.country VALUES ('PH', 'Philippines', 'PHL', 'PHILIPPINES', 608, 63);
INSERT INTO public.country VALUES ('PL', 'Poland', 'POL', 'POLAND', 616, 48);
INSERT INTO public.country VALUES ('PT', 'Portugal', 'PRT', 'PORTUGAL', 620, 351);
INSERT INTO public.country VALUES ('PR', 'Puerto Rico', 'PRI', 'PUERTO RICO', 630, 1787);
INSERT INTO public.country VALUES ('QA', 'Qatar', 'QAT', 'QATAR', 634, 974);
INSERT INTO public.country VALUES ('RE', 'Reunion', 'REU', 'REUNION', 638, 262);
INSERT INTO public.country VALUES ('RO', 'Romania', 'ROM', 'ROMANIA', 642, 40);
INSERT INTO public.country VALUES ('RU', 'Russian Federation', 'RUS', 'RUSSIAN FEDERATION', 643, 70);
INSERT INTO public.country VALUES ('RW', 'Rwanda', 'RWA', 'RWANDA', 646, 250);
INSERT INTO public.country VALUES ('SH', 'Saint Helena', 'SHN', 'SAINT HELENA', 654, 290);
INSERT INTO public.country VALUES ('KN', 'Saint Kitts and Nevis', 'KNA', 'SAINT KITTS AND NEVIS', 659, 1869);
INSERT INTO public.country VALUES ('LC', 'Saint Lucia', 'LCA', 'SAINT LUCIA', 662, 1758);
INSERT INTO public.country VALUES ('PM', 'Saint Pierre and Miquelon', 'SPM', 'SAINT PIERRE AND MIQUELON', 666, 508);
INSERT INTO public.country VALUES ('VC', 'Saint Vincent and the Grenadines', 'VCT', 'SAINT VINCENT AND THE GRENADINES', 670, 1784);
INSERT INTO public.country VALUES ('WS', 'Samoa', 'WSM', 'SAMOA', 882, 684);
INSERT INTO public.country VALUES ('SM', 'San Marino', 'SMR', 'SAN MARINO', 674, 378);
INSERT INTO public.country VALUES ('ST', 'Sao Tome and Principe', 'STP', 'SAO TOME AND PRINCIPE', 678, 239);
INSERT INTO public.country VALUES ('SA', 'Saudi Arabia', 'SAU', 'SAUDI ARABIA', 682, 966);
INSERT INTO public.country VALUES ('SN', 'Senegal', 'SEN', 'SENEGAL', 686, 221);
INSERT INTO public.country VALUES ('YT', 'Mayotte', 'MYT', 'MAYOTTE', 175, 269);
INSERT INTO public.country VALUES ('SC', 'Seychelles', 'SYC', 'SEYCHELLES', 690, 248);
INSERT INTO public.country VALUES ('SL', 'Sierra Leone', 'SLE', 'SIERRA LEONE', 694, 232);
INSERT INTO public.country VALUES ('SG', 'Singapore', 'SGP', 'SINGAPORE', 702, 65);
INSERT INTO public.country VALUES ('SK', 'Slovakia', 'SVK', 'SLOVAKIA', 703, 421);
INSERT INTO public.country VALUES ('SI', 'Slovenia', 'SVN', 'SLOVENIA', 705, 386);
INSERT INTO public.country VALUES ('SB', 'Solomon Islands', 'SLB', 'SOLOMON ISLANDS', 90, 677);
INSERT INTO public.country VALUES ('SO', 'Somalia', 'SOM', 'SOMALIA', 706, 252);
INSERT INTO public.country VALUES ('ZA', 'South Africa', 'ZAF', 'SOUTH AFRICA', 710, 27);
INSERT INTO public.country VALUES ('ES', 'Spain', 'ESP', 'SPAIN', 724, 34);
INSERT INTO public.country VALUES ('LK', 'Sri Lanka', 'LKA', 'SRI LANKA', 144, 94);
INSERT INTO public.country VALUES ('SD', 'Sudan', 'SDN', 'SUDAN', 736, 249);
INSERT INTO public.country VALUES ('SR', 'Suriname', 'SUR', 'SURINAME', 740, 597);
INSERT INTO public.country VALUES ('SJ', 'Svalbard and Jan Mayen', 'SJM', 'SVALBARD AND JAN MAYEN', 744, 47);
INSERT INTO public.country VALUES ('SZ', 'Swaziland', 'SWZ', 'SWAZILAND', 748, 268);
INSERT INTO public.country VALUES ('SE', 'Sweden', 'SWE', 'SWEDEN', 752, 46);
INSERT INTO public.country VALUES ('CH', 'Switzerland', 'CHE', 'SWITZERLAND', 756, 41);
INSERT INTO public.country VALUES ('SY', 'Syrian Arab Republic', 'SYR', 'SYRIAN ARAB REPUBLIC', 760, 963);
INSERT INTO public.country VALUES ('TW', 'Taiwan, Province of China', 'TWN', 'TAIWAN, PROVINCE OF CHINA', 158, 886);
INSERT INTO public.country VALUES ('TJ', 'Tajikistan', 'TJK', 'TAJIKISTAN', 762, 992);
INSERT INTO public.country VALUES ('TZ', 'Tanzania, United Republic of', 'TZA', 'TANZANIA, UNITED REPUBLIC OF', 834, 255);
INSERT INTO public.country VALUES ('TH', 'Thailand', 'THA', 'THAILAND', 764, 66);
INSERT INTO public.country VALUES ('TG', 'Togo', 'TGO', 'TOGO', 768, 228);
INSERT INTO public.country VALUES ('TK', 'Tokelau', 'TKL', 'TOKELAU', 772, 690);
INSERT INTO public.country VALUES ('TO', 'Tonga', 'TON', 'TONGA', 776, 676);
INSERT INTO public.country VALUES ('TT', 'Trinidad and Tobago', 'TTO', 'TRINIDAD AND TOBAGO', 780, 1868);
INSERT INTO public.country VALUES ('TN', 'Tunisia', 'TUN', 'TUNISIA', 788, 216);
INSERT INTO public.country VALUES ('TR', 'Turkey', 'TUR', 'TURKEY', 792, 90);
INSERT INTO public.country VALUES ('TM', 'Turkmenistan', 'TKM', 'TURKMENISTAN', 795, 7370);
INSERT INTO public.country VALUES ('TC', 'Turks and Caicos Islands', 'TCA', 'TURKS AND CAICOS ISLANDS', 796, 1649);
INSERT INTO public.country VALUES ('TV', 'Tuvalu', 'TUV', 'TUVALU', 798, 688);
INSERT INTO public.country VALUES ('UG', 'Uganda', 'UGA', 'UGANDA', 800, 256);
INSERT INTO public.country VALUES ('UA', 'Ukraine', 'UKR', 'UKRAINE', 804, 380);
INSERT INTO public.country VALUES ('AE', 'United Arab Emirates', 'ARE', 'UNITED ARAB EMIRATES', 784, 971);
INSERT INTO public.country VALUES ('GB', 'United Kingdom', 'GBR', 'UNITED KINGDOM', 826, 44);
INSERT INTO public.country VALUES ('US', 'United States', 'USA', 'UNITED STATES', 840, 1);
INSERT INTO public.country VALUES ('UY', 'Uruguay', 'URY', 'URUGUAY', 858, 598);
INSERT INTO public.country VALUES ('UZ', 'Uzbekistan', 'UZB', 'UZBEKISTAN', 860, 998);
INSERT INTO public.country VALUES ('VU', 'Vanuatu', 'VUT', 'VANUATU', 548, 678);
INSERT INTO public.country VALUES ('VE', 'Venezuela', 'VEN', 'VENEZUELA', 862, 58);
INSERT INTO public.country VALUES ('VN', 'Viet Nam', 'VNM', 'VIET NAM', 704, 84);
INSERT INTO public.country VALUES ('VG', 'Virgin Islands, British', 'VGB', 'VIRGIN ISLANDS, BRITISH', 92, 1284);
INSERT INTO public.country VALUES ('PN', 'Pitcairn', 'PCN', 'PITCAIRN', 612, 64);
INSERT INTO public.country VALUES ('VI', 'Virgin Islands, U.s.', 'VIR', 'VIRGIN ISLANDS, U.S.', 850, 1340);
INSERT INTO public.country VALUES ('WF', 'Wallis and Futuna', 'WLF', 'WALLIS AND FUTUNA', 876, 681);
INSERT INTO public.country VALUES ('EH', 'Western Sahara', 'ESH', 'WESTERN SAHARA', 732, 212);
INSERT INTO public.country VALUES ('YE', 'Yemen', 'YEM', 'YEMEN', 887, 967);
INSERT INTO public.country VALUES ('ZM', 'Zambia', 'ZMB', 'ZAMBIA', 894, 260);
INSERT INTO public.country VALUES ('ZW', 'Zimbabwe', 'ZWE', 'ZIMBABWE', 716, 263);
INSERT INTO public.country VALUES ('TL', 'Timor-Leste', 'TLS', 'TIMOR-LESTE', 626, 670);
INSERT INTO public.country VALUES ('AQ', 'Antarctica', 'ATA', 'ANTARCTICA', 10, 672);
INSERT INTO public.country VALUES ('TF', 'French Southern Territories', 'ATF', 'FRENCH SOUTHERN TERRITORIES', 260, 262);
INSERT INTO public.country VALUES ('RS', 'Serbia', 'SRB', 'SERBIA', 688, 381);
INSERT INTO public.country VALUES ('GS', 'South Georgia and the South Sandwich Islands', 'SGS', 'SOUTH GEORGIA AND THE SOUTH SANDWICH ISLANDS', 239, 500);
INSERT INTO public.country VALUES ('UM', 'United States Minor Outlying Islands', 'UMI', 'UNITED STATES MINOR OUTLYING ISLANDS', 581, 246);
INSERT INTO public.country VALUES ('SX', 'Sint Maarten', 'SXM', 'SINT MAARTEN', 534, 590);


--
-- TOC entry 3446 (class 0 OID 17527)
-- Dependencies: 250
-- Data for Name: language; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.language VALUES ('mh', 'Marshallese', 'Kajin Majel', 'mah', NULL);
INSERT INTO public.language VALUES ('mn', 'Mongolian', 'Монгол хэл', 'mon', NULL);
INSERT INTO public.language VALUES ('na', 'Nauru', 'Dorerin Naoero', 'nau', NULL);
INSERT INTO public.language VALUES ('nr', 'South Ndebele', 'isiNdebele', 'nbl', NULL);
INSERT INTO public.language VALUES ('nn', 'Norwegian Nynorsk', 'Norsk nynorsk', 'nno', NULL);
INSERT INTO public.language VALUES ('om', 'Oromo', 'Afaan Oromoo', 'orm', NULL);
INSERT INTO public.language VALUES ('oc', 'Occitan', 'occitan, lenga d''òc', 'oci', NULL);
INSERT INTO public.language VALUES ('os', 'Ossetian / Ossetic', 'ирон ӕвзаг', 'oss', NULL);
INSERT INTO public.language VALUES ('pl', 'Polish', 'język polski, polszczyzna', 'pol', NULL);
INSERT INTO public.language VALUES ('qu', 'Quechua', 'Runa Simi, Kichwa', 'que', NULL);
INSERT INTO public.language VALUES ('ps', 'Pashto / Pushto', 'پښتو', 'pus', NULL);
INSERT INTO public.language VALUES ('rm', 'Romansh', 'Rumantsch Grischun', 'roh', NULL);
INSERT INTO public.language VALUES ('rn', 'Rundi', 'Ikirundi', 'run', NULL);
INSERT INTO public.language VALUES ('sm', 'Samoan', 'gagana fa''a Samoa', 'smo', NULL);
INSERT INTO public.language VALUES ('sg', 'Sango', 'yângâ tî sängö', 'sag', NULL);
INSERT INTO public.language VALUES ('sr', 'Serbian', 'српски језик', 'srp', NULL);
INSERT INTO public.language VALUES ('sl', 'Slovenian', 'Slovenski jezik, Slovenščina', 'slv', NULL);
INSERT INTO public.language VALUES ('tl', 'Tagalog', 'Wikang Tagalog', 'tgl', NULL);
INSERT INTO public.language VALUES ('ty', 'Tahitian', 'Reo Tahiti', 'tah', NULL);
INSERT INTO public.language VALUES ('tt', 'Tatar', 'татар теле, tatar tele', 'tat', NULL);
INSERT INTO public.language VALUES ('bo', 'Tibetan', 'བོད་ཡིག', 'tib', NULL);
INSERT INTO public.language VALUES ('fy', 'Western Frisian', 'Frysk', 'fry', NULL);
INSERT INTO public.language VALUES ('eo', 'Esperanto', 'Esperanto', 'epo', NULL);
INSERT INTO public.language VALUES ('cv', 'Chuvash', 'Чăваш чӗлхи', 'chv', NULL);
INSERT INTO public.language VALUES ('aa', 'Afar', 'Afar', 'aar', NULL);
INSERT INTO public.language VALUES ('av', 'Avaric', 'авар мацӀ, магӀарул мацӀ', 'ava', NULL);
INSERT INTO public.language VALUES ('af', 'Afrikaans', 'Afrikaans', 'afr', NULL);
INSERT INTO public.language VALUES ('ts', 'Tsonga', 'Xitsonga', 'tso', NULL);
INSERT INTO public.language VALUES ('as', 'Assamese', 'অসমীয়া', 'asm', NULL);
INSERT INTO public.language VALUES ('ig', 'Igbo', 'Asụsụ Igbo', 'ibo', NULL);
INSERT INTO public.language VALUES ('ae', 'Avestan', 'Avestan', 'ave', NULL);
INSERT INTO public.language VALUES ('tn', 'Tswana', 'Setswana', 'tsn', NULL);
INSERT INTO public.language VALUES ('ti', 'Tigrinya', 'ትግርኛ', 'tir', NULL);
INSERT INTO public.language VALUES ('ta', 'Tamil', 'தமிழ்', 'tam', NULL);
INSERT INTO public.language VALUES ('sv', 'Swedish', 'Svenska', 'swe', NULL);
INSERT INTO public.language VALUES ('ss', 'Swati', 'SiSwati', 'ssw', NULL);
INSERT INTO public.language VALUES ('sc', 'Sardinian', 'Sardu', 'srd', NULL);
INSERT INTO public.language VALUES ('st', 'Southern Sotho', 'Sesotho', 'sot', NULL);
INSERT INTO public.language VALUES ('sn', 'Shona', 'chiShona', 'sna', NULL);
INSERT INTO public.language VALUES ('sd', 'Sindhi', 'सिनधि', 'snd', NULL);
INSERT INTO public.language VALUES ('sk', 'Slovak', 'Slovenčina', 'slo', NULL);
INSERT INTO public.language VALUES ('si', 'Sinhalese', 'සිංහල', 'sin', NULL);
INSERT INTO public.language VALUES ('ru', 'Russian', 'Русский', 'rus', NULL);
INSERT INTO public.language VALUES ('fa', 'Persian', 'فارسی', 'per', NULL);
INSERT INTO public.language VALUES ('pt', 'Portuguese', 'Português', 'por', NULL);
INSERT INTO public.language VALUES ('es', 'Spanish / Castilian', 'Español', 'spa', NULL);
INSERT INTO public.language VALUES ('no', 'Norwegian', 'Norsk', 'nor', NULL);
INSERT INTO public.language VALUES ('zh', 'Chinese', '中文 (Zhōngwén), 汉语, 漢語', 'chi', NULL);
INSERT INTO public.language VALUES ('or', 'Oriya', 'ଓଡ଼ିଆ', 'ori', NULL);
INSERT INTO public.language VALUES ('ne', 'Nepali', 'नेपाली', 'nep', NULL);
INSERT INTO public.language VALUES ('ng', 'Ndonga', 'Oshiwambo', 'ndo', NULL);
INSERT INTO public.language VALUES ('nv', 'Navajo / Navaho', 'Diné bizaad', 'nav', NULL);
INSERT INTO public.language VALUES ('mi', 'Maori', 'te reo Māori', 'mao', NULL);
INSERT INTO public.language VALUES ('mr', 'Marathi', 'मराठी', 'mar', NULL);
INSERT INTO public.language VALUES ('mt', 'Maltese', 'Malti', 'mlt', NULL);
INSERT INTO public.language VALUES ('lg', 'Ganda', 'Luganda', 'lug', NULL);
INSERT INTO public.language VALUES ('lb', 'Luxembourgish / Letzeburgesch', 'Lëtzebuergesch', 'ltz', NULL);
INSERT INTO public.language VALUES ('ln', 'Lingala', 'Lingála', 'lin', NULL);
INSERT INTO public.language VALUES ('lv', 'Latvian', 'Latviešu', 'lav', NULL);
INSERT INTO public.language VALUES ('li', 'Limburgan / Limburger / Limburgish', 'Limburgs', 'lim', NULL);
INSERT INTO public.language VALUES ('mk', 'Macedonian', 'македонски јазик', 'mac', NULL);
INSERT INTO public.language VALUES ('la', 'Latin', 'Latina', 'lat', NULL);
INSERT INTO public.language VALUES ('kg', 'Kongo', 'KiKongo', 'kon', NULL);
INSERT INTO public.language VALUES ('ko', 'Korean', '한국어', 'kor', NULL);
INSERT INTO public.language VALUES ('lo', 'Lao', 'ພາສາລາວ', 'lao', NULL);
INSERT INTO public.language VALUES ('ky', 'Kirghiz / Kyrgyz', 'Kırgızca / Кыргызча', 'kir', NULL);
INSERT INTO public.language VALUES ('ki', 'Kikuyu / Gikuyu', 'Gĩkũyũ', 'kik', NULL);
INSERT INTO public.language VALUES ('ks', 'Kashmiri', 'कश्मीरी / كشميري', 'kas', NULL);
INSERT INTO public.language VALUES ('kr', 'Kanuri', 'Kanuri', 'kau', NULL);
INSERT INTO public.language VALUES ('kv', 'Komi', 'коми кыв', 'kom', NULL);
INSERT INTO public.language VALUES ('it', 'Italian', 'Italiano', 'ita', NULL);
INSERT INTO public.language VALUES ('kl', 'Kalaallisut / Greenlandic', 'kalaallisut, kalaallit oqaasii', 'kal', NULL);
INSERT INTO public.language VALUES ('kk', 'Kazakh', 'қазақ тілі', 'kaz', NULL);
INSERT INTO public.language VALUES ('kn', 'Kannada', 'ಕನ್ನಡ', 'kan', NULL);
INSERT INTO public.language VALUES ('ie', 'Interlingue / Occidental', 'Interlingue', 'ile', NULL);
INSERT INTO public.language VALUES ('iu', 'Inuktitut', 'ᐃᓄᒃᑎᑐᑦ', 'iku', NULL);
INSERT INTO public.language VALUES ('ii', 'Sichuan Yi / Nuosu', 'ꆇꉙ / 四川彝语', 'iii', NULL);
INSERT INTO public.language VALUES ('ny', 'Chichewa / Chewa / Nyanja', 'ChiCheŵa, chinyanja', 'nya', NULL);
INSERT INTO public.language VALUES ('io', 'Ido', 'Ido', 'ido', NULL);
INSERT INTO public.language VALUES ('is', 'Icelandic', 'Íslenska', 'ice', NULL);
INSERT INTO public.language VALUES ('nl', 'Dutch / Flemish', 'Nederlands, Vlaams', 'dut', NULL);
INSERT INTO public.language VALUES ('hu', 'Hungarian', 'Magyar', 'hun', NULL);
INSERT INTO public.language VALUES ('he', 'Hebrew', 'עברית', 'heb', NULL);
INSERT INTO public.language VALUES ('hz', 'Herero', 'Otsiherero', 'her', NULL);
INSERT INTO public.language VALUES ('ho', 'Hiri Motu', 'Hiri Motu', 'hmo', NULL);
INSERT INTO public.language VALUES ('ht', 'Haitian / Haitian Creole', 'Krèyol ayisyen', 'hat', NULL);
INSERT INTO public.language VALUES ('ha', 'Hausa', 'هَوُسَ', 'hau', NULL);
INSERT INTO public.language VALUES ('ka', 'Georgian', 'ქართული', 'geo', NULL);
INSERT INTO public.language VALUES ('gd', 'Scottish Gaelic / Gaelic', 'Gàidhlig', 'gla', NULL);
INSERT INTO public.language VALUES ('ga', 'Irish', 'Gaeilge', 'gle', NULL);
INSERT INTO public.language VALUES ('gl', 'Galician', 'Galego', 'glg', NULL);
INSERT INTO public.language VALUES ('gn', 'Guarani', 'Avañe''ẽ', 'grn', NULL);
INSERT INTO public.language VALUES ('hi', 'Hindi', 'हिन्दी, हिंदी', 'hin', NULL);
INSERT INTO public.language VALUES ('fi', 'Finnish', 'Suomi', 'fin', NULL);
INSERT INTO public.language VALUES ('fr', 'French', 'Français', 'fre', NULL);
INSERT INTO public.language VALUES ('fo', 'Faroese', 'Føroyskt', 'fao', NULL);
INSERT INTO public.language VALUES ('ff', 'Fulah', 'Fulfulde, Pulaar, Pular', 'ful', NULL);
INSERT INTO public.language VALUES ('et', 'Estonian', 'Eesti', 'est', NULL);
INSERT INTO public.language VALUES ('ee', 'Ewe', 'Eʋegbe', 'ewe', NULL);
INSERT INTO public.language VALUES ('cs', 'Czech', 'Česky', 'cze', NULL);
INSERT INTO public.language VALUES ('da', 'Danish', 'Dansk', 'dan', NULL);
INSERT INTO public.language VALUES ('co', 'Corsican', 'Corsu', 'cos', NULL);
INSERT INTO public.language VALUES ('kw', 'Cornish', 'Kernewek', 'cor', NULL);
INSERT INTO public.language VALUES ('cr', 'Cree', 'Nehiyaw, 	ᓀᐦᐃᔭᐍᐏᐣ', 'cre', NULL);
INSERT INTO public.language VALUES ('ce', 'Chechen', 'Нохчийн мотт', 'che', NULL);
INSERT INTO public.language VALUES ('my', 'Burmese', 'မြန်မာစာ', 'bur', NULL);
INSERT INTO public.language VALUES ('ba', 'Bashkir', 'Башҡорт', 'bak', NULL);
INSERT INTO public.language VALUES ('eu', 'Basque', 'Euskara', 'baq', NULL);
INSERT INTO public.language VALUES ('bg', 'Bulgarian', 'Български език', 'bul', NULL);
INSERT INTO public.language VALUES ('bi', 'Bislama', 'Bislama', 'bis', NULL);
INSERT INTO public.language VALUES ('bs', 'Bosnian', 'Bosanski', 'bos', NULL);
INSERT INTO public.language VALUES ('ay', 'Aymara', 'Aymar', 'aym', NULL);
INSERT INTO public.language VALUES ('be', 'Belarusian', 'Беларуская мова', 'bel', NULL);
INSERT INTO public.language VALUES ('hy', 'Armenian', 'Հայերեն', 'arm', NULL);
INSERT INTO public.language VALUES ('ar', 'Arabic', 'العربية', 'ara', NULL);
INSERT INTO public.language VALUES ('am', 'Amharic', 'አማርኛ', 'amh', NULL);
INSERT INTO public.language VALUES ('sq', 'Albanian', 'Shqip', 'alb', NULL);
INSERT INTO public.language VALUES ('vi', 'Vietnamese', 'Tiếng Việt', 'vie', NULL);
INSERT INTO public.language VALUES ('en', 'English', 'English', 'eng', NULL);
INSERT INTO public.language VALUES ('zu', 'Zulu', 'isiZulu', 'zul', NULL);
INSERT INTO public.language VALUES ('nd', 'North Ndebele', 'isiNdebele', 'nde', NULL);
INSERT INTO public.language VALUES ('yo', 'Yoruba', 'Yorùbá', 'yor', NULL);
INSERT INTO public.language VALUES ('yi', 'Yiddish', 'ייִדיש', 'yid', NULL);
INSERT INTO public.language VALUES ('xh', 'Xhosa', 'isiXhosa', 'xho', NULL);
INSERT INTO public.language VALUES ('wo', 'Wolof', 'Wollof', 'wol', NULL);
INSERT INTO public.language VALUES ('vo', 'Volapük', 'Volapük', 'vol', NULL);
INSERT INTO public.language VALUES ('wa', 'Walloon', 'Walon', 'wln', NULL);
INSERT INTO public.language VALUES ('ak', 'Akan', 'Akana', 'aka', NULL);
INSERT INTO public.language VALUES ('bh', 'Bihari languages', 'भोजपुरी', 'bih', NULL);
INSERT INTO public.language VALUES ('ug', 'Uyghur', 'Uyƣurqə / ئۇيغۇرچە', 'uig', NULL);
INSERT INTO public.language VALUES ('uk', 'Ukrainian', 'Українська', 'ukr', NULL);
INSERT INTO public.language VALUES ('ur', 'Urdu', 'اردو', 'urd', NULL);
INSERT INTO public.language VALUES ('uz', 'Uzbek', 'Ўзбек', 'uzb', NULL);
INSERT INTO public.language VALUES ('ve', 'Venda', 'Tshivenḓa', 'ven', NULL);
INSERT INTO public.language VALUES ('cy', 'Welsh', 'Cymraeg', 'wel', NULL);
INSERT INTO public.language VALUES ('tr', 'Turkish', 'Türkçe', 'tur', NULL);
INSERT INTO public.language VALUES ('tw', 'Twi', 'Twi', 'twi', NULL);
INSERT INTO public.language VALUES ('tk', 'Turkmen', 'Туркмен / تركمن', 'tuk', NULL);
INSERT INTO public.language VALUES ('to', 'Tonga (Tonga Islands)', 'Lea Faka-Tonga', 'ton', NULL);
INSERT INTO public.language VALUES ('th', 'Thai', 'ไทย / Phasa Thai', 'tha', NULL);
INSERT INTO public.language VALUES ('te', 'Telugu', 'తెలుగు', 'tel', NULL);
INSERT INTO public.language VALUES ('sw', 'Swahili', 'Kiswahili', 'swa', NULL);
INSERT INTO public.language VALUES ('su', 'Sundanese', 'Basa Sunda', 'sun', NULL);
INSERT INTO public.language VALUES ('sa', 'Sanskrit', 'संस्कृतम्', 'san', NULL);
INSERT INTO public.language VALUES ('pi', 'Pali', 'Pāli / पाऴि', 'pli', NULL);
INSERT INTO public.language VALUES ('se', 'Northern Sami', 'Davvisámegiella', 'sme', NULL);
INSERT INTO public.language VALUES ('el', 'Greek', 'Ελληνικά', 'gre', NULL);
INSERT INTO public.language VALUES ('za', 'Zhuang / Chuang', 'Cuengh / Tôô / 壮语', 'zha', NULL);
INSERT INTO public.language VALUES ('ro', 'Romanian / Moldavian / Moldovan', 'Română', 'rum', NULL);
INSERT INTO public.language VALUES ('ml', 'Malayalam', 'മലയാളം', 'mal', NULL);
INSERT INTO public.language VALUES ('ku', 'Kurdish', 'Kurdî / كوردی', 'kur', NULL);
INSERT INTO public.language VALUES ('kj', 'Kuanyama / Kwanyama', 'Kuanyama', 'kua', NULL);
INSERT INTO public.language VALUES ('oj', 'Ojibwa', 'ᐊᓂᔑᓈᐯᒧᐎᓐ', 'oji', NULL);
INSERT INTO public.language VALUES ('id', 'Indonesian', 'Bahasa Indonesia', 'ind', NULL);
INSERT INTO public.language VALUES ('ia', 'Interlingua', 'Interlingua', 'ina', NULL);
INSERT INTO public.language VALUES ('de', 'German', 'Deutsch', 'ger', NULL);
INSERT INTO public.language VALUES ('gu', 'Gujarati', 'ગુજરાતી', 'guj', NULL);
INSERT INTO public.language VALUES ('dz', 'Dzongkha', 'ཇོང་ཁ', 'dzo', NULL);
INSERT INTO public.language VALUES ('dv', 'Divehi / Dhivehi / Maldivian', 'ދިވެހިބަސް', 'div', NULL);
INSERT INTO public.language VALUES ('ch', 'Chamorro', 'Chamoru', 'cha', NULL);
INSERT INTO public.language VALUES ('br', 'Breton', 'Brezhoneg', 'bre', NULL);
INSERT INTO public.language VALUES ('bm', 'Bambara', 'Bamanankan', 'bam', NULL);
INSERT INTO public.language VALUES ('bn', 'Bengali', 'বাংলা', 'ben', NULL);
INSERT INTO public.language VALUES ('az', 'Azerbaijani', 'Azərbaycanca / آذربايجان', 'aze', NULL);
INSERT INTO public.language VALUES ('an', 'Aragonese', 'Aragonés', 'arg', NULL);
INSERT INTO public.language VALUES ('ab', 'Abkhazian', 'аҧсуа бызшәа, аҧсшәа', 'abk', NULL);
INSERT INTO public.language VALUES ('nb', 'Norwegian Bokmål', 'Norsk bokmål', 'nob', NULL);
INSERT INTO public.language VALUES ('km', 'Central Khmer', 'ខ្មែរ, ខេមរភាសា, ភាសាខ្មែរ', 'khm', NULL);
INSERT INTO public.language VALUES ('ca', 'Catalan / Valencian', 'Català, valencià', 'cat', NULL);
INSERT INTO public.language VALUES ('hr', 'Croatian', 'Hrvatski jezik', 'hrv', NULL);
INSERT INTO public.language VALUES ('fj', 'Fijian', 'Vosa Vakaviti', 'fij', NULL);
INSERT INTO public.language VALUES ('ik', 'Inupiaq', 'Iñupiaq, Iñupiatun', 'ipk', NULL);
INSERT INTO public.language VALUES ('ja', 'Japanese', '日本語 (にほんご)', 'jpn', NULL);
INSERT INTO public.language VALUES ('jv', 'Javanese', 'ꦧꦱꦗꦮ, Basa Jawa', 'jav', NULL);
INSERT INTO public.language VALUES ('rw', 'Kinyarwanda', 'Ikinyarwanda', 'kin', NULL);
INSERT INTO public.language VALUES ('lt', 'Lithuanian', 'lietuvių kalba', 'lit', NULL);
INSERT INTO public.language VALUES ('lu', 'Luba-Katanga', 'Kiluba', 'lub', NULL);
INSERT INTO public.language VALUES ('mg', 'Malagasy', 'fiteny malagasy', 'mlg', NULL);
INSERT INTO public.language VALUES ('ms', 'Malay', 'Bahasa Melayu, بهاس ملايو', 'may', NULL);
INSERT INTO public.language VALUES ('gv', 'Manx', 'Gaelg, Gailck', 'glv', NULL);
INSERT INTO public.language VALUES ('pa', 'Punjabi / Panjabi', 'ਪੰਜਾਬੀ / पंजाबी / پنجابي', 'pan', NULL);
INSERT INTO public.language VALUES ('cu', 'Church Slavic / Old Slavonic / Church Slavonic / Old Bulgarian / Old Church Slavonic', 'ѩзыкъ словѣньскъ', 'chu', NULL);
INSERT INTO public.language VALUES ('so', 'Somali', 'Soomaaliga, af Soomaali', 'som', NULL);
INSERT INTO public.language VALUES ('tg', 'Tajik', 'тоҷикӣ, toçikī, تاجیکی', 'tgk', NULL);


--
-- TOC entry 3459 (class 0 OID 18913)
-- Dependencies: 263
-- Data for Name: liketype; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.liketype VALUES ('normal', 'normal');
INSERT INTO public.liketype VALUES ('heart', 'heart');
INSERT INTO public.liketype VALUES ('haha', 'haha');
INSERT INTO public.liketype VALUES ('angry', 'angry');
INSERT INTO public.liketype VALUES ('sad', 'sad');
INSERT INTO public.liketype VALUES ('ask', 'ask');
INSERT INTO public.liketype VALUES ('love', 'love');


--
-- TOC entry 3454 (class 0 OID 18781)
-- Dependencies: 258
-- Data for Name: media; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- TOC entry 3447 (class 0 OID 17686)
-- Dependencies: 251
-- Data for Name: oauth2client; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.oauth2client VALUES ('f8a61913-9d89-4f0e-8090-4aeed53675ee', 604800, NULL, true, 'refresh_token,password', NULL, 2592000, NULL, 'user_profile', '$2a$12$qo95peQMz5qjt35PQStxvO.usHUz7Ls.TpL5UfgBl5jU4QiaW2koW', 'skillful-lamp-production.up.railway.app');
INSERT INTO public.oauth2client VALUES ('98f1edad-0410-4fa0-be8c-40133cc0d64f', 604800, NULL, true, 'refresh_token,password', NULL, 2592000, NULL, 'user_profile', '$2a$12$qo95peQMz5qjt35PQStxvO.usHUz7Ls.TpL5UfgBl5jU4QiaW2koW', 'app-vocabulary.vercel.app');
INSERT INTO public.oauth2client VALUES ('01927f6d-bed6-4d59-afa5-267450cc253e', 2592000, NULL, true, 'refresh_token,client_credentials', NULL, 5184000, NULL, 'server', '$2a$12$DcUar.OriwYhMSvOrjG8h.YP/KTcWoCF.eaYyuELiwKt2ZKBhPG82', 'localhost');


--
-- TOC entry 3452 (class 0 OID 18707)
-- Dependencies: 256
-- Data for Name: post; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- TOC entry 3460 (class 0 OID 18921)
-- Dependencies: 264
-- Data for Name: postlike; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- TOC entry 3456 (class 0 OID 18804)
-- Dependencies: 260
-- Data for Name: posttag; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- TOC entry 3449 (class 0 OID 18567)
-- Dependencies: 253
-- Data for Name: socialnetwork; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.socialnetwork VALUES (1, 'GOOGLE', NULL, NULL);
INSERT INTO public.socialnetwork VALUES (2, 'FACEBOOK', NULL, NULL);


--
-- TOC entry 3457 (class 0 OID 18809)
-- Dependencies: 261
-- Data for Name: tag; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.tag VALUES ('#Tien_Bip');
INSERT INTO public.tag VALUES ('#Bong_Da');
INSERT INTO public.tag VALUES ('#Chi_Ong_Nau');
INSERT INTO public.tag VALUES ('#Ba_Phuong_Hang');
INSERT INTO public.tag VALUES ('#Chim_Canh_Cut');
INSERT INTO public.tag VALUES ('#Dark');
INSERT INTO public.tag VALUES ('#Xin_link');
INSERT INTO public.tag VALUES ('#Thay_Huan');
INSERT INTO public.tag VALUES ('#Cheems');
INSERT INTO public.tag VALUES ('#Gau_Truc');
INSERT INTO public.tag VALUES ('#Gau_Cho');
INSERT INTO public.tag VALUES ('#Cho');
INSERT INTO public.tag VALUES ('#Meo');
INSERT INTO public.tag VALUES ('hi_Nau');
INSERT INTO public.tag VALUES ('zzzz');
INSERT INTO public.tag VALUES ('zzz');
INSERT INTO public.tag VALUES ('ee');
INSERT INTO public.tag VALUES ('cccc');


--
-- TOC entry 3448 (class 0 OID 17749)
-- Dependencies: 252
-- Data for Name: user_sys; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.user_sys VALUES ('98f1edad-0410-4fa0-be8c-40133cc0d64f', 'account-public', '2021-08-24 14:44:33', 'account-public', '2021-08-24 14:44:33', 'https://lh3.googleusercontent.com/a/AATXAJwXAwTcL8lHydt_BQLuAKX18VdjxGrW0kuaP9JW=s96-c', true, 'Nguyễn Đình Tạo', '$2a$10$cYsb/fv.GwxxGEc3IKVqOucYYzg31/PDG9gWCGlPWrSQurryHFn0C', 'admin', 'no_email@choydy.com', true, 'Asia/Ho_Chi_Minh');


--
-- TOC entry 3458 (class 0 OID 18832)
-- Dependencies: 262
-- Data for Name: userauthority; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.userauthority VALUES ('be8b3e2b-8284-441e-9905-2e316a30b902', 'ADMIN', '98f1edad-0410-4fa0-be8c-40133cc0d64f');
INSERT INTO public.userauthority VALUES ('98f1edad-0410-4fa0-be8c-40133cc0d64f', 'USER', '98f1edad-0410-4fa0-be8c-40133cc0d64f');
INSERT INTO public.userauthority VALUES ('da3a324e-12c2-4b3a-9b8e-473c41c6ca58', 'EDITOR', '98f1edad-0410-4fa0-be8c-40133cc0d64f');


--
-- TOC entry 3450 (class 0 OID 18580)
-- Dependencies: 254
-- Data for Name: userdetail; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.userdetail VALUES ('98f1edad-0410-4fa0-be8c-40133cc0d64f', 'Admin hệ thống', 'Quy Nhơn, Bình Định', '1995-05-25', 'MALE', '+999999999', '591300', 'VN', '98f1edad-0410-4fa0-be8c-40133cc0d64f');


--
-- TOC entry 3451 (class 0 OID 18588)
-- Dependencies: 255
-- Data for Name: usersocialnetwork; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- TOC entry 3467 (class 0 OID 0)
-- Dependencies: 249
-- Name: hibernate_sequence; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.hibernate_sequence', 1, false);


--
-- TOC entry 3233 (class 2606 OID 17774)
-- Name: authority authority_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.authority
    ADD CONSTRAINT authority_pkey PRIMARY KEY (id);


--
-- TOC entry 3271 (class 2606 OID 18803)
-- Name: catalog catalog_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.catalog
    ADD CONSTRAINT catalog_pkey PRIMARY KEY (id);


--
-- TOC entry 3267 (class 2606 OID 18765)
-- Name: comment comment_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.comment
    ADD CONSTRAINT comment_pkey PRIMARY KEY (id);


--
-- TOC entry 3235 (class 2606 OID 17782)
-- Name: country country_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.country
    ADD CONSTRAINT country_pkey PRIMARY KEY (iso);


--
-- TOC entry 3237 (class 2606 OID 17788)
-- Name: language language_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.language
    ADD CONSTRAINT language_pkey PRIMARY KEY (code);


--
-- TOC entry 3281 (class 2606 OID 18920)
-- Name: liketype liketype_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.liketype
    ADD CONSTRAINT liketype_pkey PRIMARY KEY (id);


--
-- TOC entry 3269 (class 2606 OID 18788)
-- Name: media media_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.media
    ADD CONSTRAINT media_pkey PRIMARY KEY (id);


--
-- TOC entry 3239 (class 2606 OID 17842)
-- Name: oauth2client oauth2client_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.oauth2client
    ADD CONSTRAINT oauth2client_pkey PRIMARY KEY (id);


--
-- TOC entry 3265 (class 2606 OID 18714)
-- Name: post post_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.post
    ADD CONSTRAINT post_pkey PRIMARY KEY (id);


--
-- TOC entry 3283 (class 2606 OID 18925)
-- Name: postlike postlike_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.postlike
    ADD CONSTRAINT postlike_pkey PRIMARY KEY (user_id, post_id);


--
-- TOC entry 3273 (class 2606 OID 18808)
-- Name: posttag posttag_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.posttag
    ADD CONSTRAINT posttag_pkey PRIMARY KEY (tag_id, post_id);


--
-- TOC entry 3250 (class 2606 OID 18574)
-- Name: socialnetwork socialnetwork_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.socialnetwork
    ADD CONSTRAINT socialnetwork_pkey PRIMARY KEY (id);


--
-- TOC entry 3275 (class 2606 OID 18816)
-- Name: tag tag_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tag
    ADD CONSTRAINT tag_pkey PRIMARY KEY (id);


--
-- TOC entry 3252 (class 2606 OID 18599)
-- Name: socialnetwork uk_2s1vq8bhmy1808f219jajrl2b; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.socialnetwork
    ADD CONSTRAINT uk_2s1vq8bhmy1808f219jajrl2b UNIQUE (name);


--
-- TOC entry 3241 (class 2606 OID 17864)
-- Name: user_sys uk_5hl4w53pryqi6yvk9xlj9q7qn; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_sys
    ADD CONSTRAINT uk_5hl4w53pryqi6yvk9xlj9q7qn UNIQUE (username);


--
-- TOC entry 3254 (class 2606 OID 18605)
-- Name: userdetail uk_ogldqocqgiidnxc0phek5u6r; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.userdetail
    ADD CONSTRAINT uk_ogldqocqgiidnxc0phek5u6r UNIQUE (user_id);


--
-- TOC entry 3243 (class 2606 OID 18601)
-- Name: user_sys uk_pjjobtr3fx54k6d3hj8mgsoa5; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_sys
    ADD CONSTRAINT uk_pjjobtr3fx54k6d3hj8mgsoa5 UNIQUE (email);


--
-- TOC entry 3245 (class 2606 OID 17876)
-- Name: user_sys ukbyqgxl187y7aer3tki0jd0qr3; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_sys
    ADD CONSTRAINT ukbyqgxl187y7aer3tki0jd0qr3 UNIQUE (username, email);


--
-- TOC entry 3277 (class 2606 OID 18838)
-- Name: userauthority ukd2dmkumx3e97vu2shhg9kk2gu; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.userauthority
    ADD CONSTRAINT ukd2dmkumx3e97vu2shhg9kk2gu UNIQUE (user_id, authority_id);


--
-- TOC entry 3285 (class 2606 OID 18927)
-- Name: postlike ukqxvn7078ensy4qaar2r2yi4yx; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.postlike
    ADD CONSTRAINT ukqxvn7078ensy4qaar2r2yi4yx UNIQUE (post_id, user_id, liketype_id);


--
-- TOC entry 3258 (class 2606 OID 18607)
-- Name: usersocialnetwork uksn7bvt6g2a8i8m65cvmjsfske; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.usersocialnetwork
    ADD CONSTRAINT uksn7bvt6g2a8i8m65cvmjsfske UNIQUE (user_id, social_network_id);


--
-- TOC entry 3248 (class 2606 OID 17918)
-- Name: user_sys user_sys_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_sys
    ADD CONSTRAINT user_sys_pkey PRIMARY KEY (id);


--
-- TOC entry 3279 (class 2606 OID 18836)
-- Name: userauthority userauthority_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.userauthority
    ADD CONSTRAINT userauthority_pkey PRIMARY KEY (id);


--
-- TOC entry 3256 (class 2606 OID 18587)
-- Name: userdetail userdetail_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.userdetail
    ADD CONSTRAINT userdetail_pkey PRIMARY KEY (id);


--
-- TOC entry 3260 (class 2606 OID 18595)
-- Name: usersocialnetwork usersocialnetwork_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.usersocialnetwork
    ADD CONSTRAINT usersocialnetwork_pkey PRIMARY KEY (id);


--
-- TOC entry 3261 (class 1259 OID 18943)
-- Name: idxgj2rd9ewi9h2p4pc09i6upyt1; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idxgj2rd9ewi9h2p4pc09i6upyt1 ON public.post USING btree (created);


--
-- TOC entry 3262 (class 1259 OID 18722)
-- Name: idxote8luhmq2ditx56w37mviwny; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idxote8luhmq2ditx56w37mviwny ON public.post USING btree (title, content);


--
-- TOC entry 3263 (class 1259 OID 18721)
-- Name: idxs7ui38nhrh0c7q4nfpgf93bfk; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idxs7ui38nhrh0c7q4nfpgf93bfk ON public.post USING btree (user_id);


--
-- TOC entry 3246 (class 1259 OID 17936)
-- Name: user_sys_email_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX user_sys_email_idx ON public.user_sys USING btree (email);


--
-- TOC entry 3296 (class 2606 OID 18822)
-- Name: posttag fk16gha3b1hvtdmklc4qmhxs4te; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.posttag
    ADD CONSTRAINT fk16gha3b1hvtdmklc4qmhxs4te FOREIGN KEY (tag_id) REFERENCES public.tag(id);


--
-- TOC entry 3286 (class 2606 OID 18633)
-- Name: userdetail fk174y51lt1lbl26clh4ymguuk3; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.userdetail
    ADD CONSTRAINT fk174y51lt1lbl26clh4ymguuk3 FOREIGN KEY (country_iso) REFERENCES public.country(iso);


--
-- TOC entry 3298 (class 2606 OID 18839)
-- Name: userauthority fk1minklvli2mn2njbomxvef99g; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.userauthority
    ADD CONSTRAINT fk1minklvli2mn2njbomxvef99g FOREIGN KEY (authority_id) REFERENCES public.authority(id);


--
-- TOC entry 3292 (class 2606 OID 18766)
-- Name: comment fk6kduoq1qgemmbt8ls3x37di8n; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.comment
    ADD CONSTRAINT fk6kduoq1qgemmbt8ls3x37di8n FOREIGN KEY (parent_id) REFERENCES public.comment(id);


--
-- TOC entry 3287 (class 2606 OID 18638)
-- Name: userdetail fk9kj1yufdk6lpcvs4hc9aki689; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.userdetail
    ADD CONSTRAINT fk9kj1yufdk6lpcvs4hc9aki689 FOREIGN KEY (user_id) REFERENCES public.user_sys(id);


--
-- TOC entry 3293 (class 2606 OID 18776)
-- Name: comment fkay3w7wrk7vau26n7ix6crwl1l; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.comment
    ADD CONSTRAINT fkay3w7wrk7vau26n7ix6crwl1l FOREIGN KEY (user_id) REFERENCES public.user_sys(id);


--
-- TOC entry 3288 (class 2606 OID 18643)
-- Name: usersocialnetwork fkcjc5u98wa8eymfb2mw57kfp9m; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.usersocialnetwork
    ADD CONSTRAINT fkcjc5u98wa8eymfb2mw57kfp9m FOREIGN KEY (social_network_id) REFERENCES public.socialnetwork(id);


--
-- TOC entry 3300 (class 2606 OID 18938)
-- Name: postlike fkdfoyq2vrvmh47km1jejktsem8; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.postlike
    ADD CONSTRAINT fkdfoyq2vrvmh47km1jejktsem8 FOREIGN KEY (liketype_id) REFERENCES public.liketype(id);


--
-- TOC entry 3297 (class 2606 OID 18827)
-- Name: posttag fkijuqbnbv01ixs71tbd58xkgkd; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.posttag
    ADD CONSTRAINT fkijuqbnbv01ixs71tbd58xkgkd FOREIGN KEY (post_id) REFERENCES public.post(id);


--
-- TOC entry 3299 (class 2606 OID 18844)
-- Name: userauthority fkjnag5ndsv1g0v1bsrwas0fibt; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.userauthority
    ADD CONSTRAINT fkjnag5ndsv1g0v1bsrwas0fibt FOREIGN KEY (user_id) REFERENCES public.user_sys(id);


--
-- TOC entry 3290 (class 2606 OID 18817)
-- Name: post fkknuxya8iel3o3odnc1u2c7pp2; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.post
    ADD CONSTRAINT fkknuxya8iel3o3odnc1u2c7pp2 FOREIGN KEY (catalog_id) REFERENCES public.catalog(id);


--
-- TOC entry 3289 (class 2606 OID 18648)
-- Name: usersocialnetwork fko7d0gpfdlq9if52g0fecsfxso; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.usersocialnetwork
    ADD CONSTRAINT fko7d0gpfdlq9if52g0fecsfxso FOREIGN KEY (user_id) REFERENCES public.user_sys(id);


--
-- TOC entry 3294 (class 2606 OID 18771)
-- Name: comment fkqb0rnht649ifuh6gev5lwvx8x; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.comment
    ADD CONSTRAINT fkqb0rnht649ifuh6gev5lwvx8x FOREIGN KEY (post_id) REFERENCES public.post(id);


--
-- TOC entry 3301 (class 2606 OID 18928)
-- Name: postlike fkrfesdq1ogr4mt2qxfl241h6ud; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.postlike
    ADD CONSTRAINT fkrfesdq1ogr4mt2qxfl241h6ud FOREIGN KEY (user_id) REFERENCES public.user_sys(id);


--
-- TOC entry 3291 (class 2606 OID 18723)
-- Name: post fkt4kvk5faoe6k9lmq0m7bvqjcg; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.post
    ADD CONSTRAINT fkt4kvk5faoe6k9lmq0m7bvqjcg FOREIGN KEY (user_id) REFERENCES public.user_sys(id);


--
-- TOC entry 3295 (class 2606 OID 18791)
-- Name: media fktmgj1wjq6o74oq675050lhrb0; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.media
    ADD CONSTRAINT fktmgj1wjq6o74oq675050lhrb0 FOREIGN KEY (post_id) REFERENCES public.post(id);


--
-- TOC entry 3302 (class 2606 OID 18933)
-- Name: postlike fkwy2u3sijki3uk1jhyq1wwujw; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.postlike
    ADD CONSTRAINT fkwy2u3sijki3uk1jhyq1wwujw FOREIGN KEY (post_id) REFERENCES public.post(id);


-- Completed on 2021-12-17 16:30:56

--
-- PostgreSQL database dump complete
--

